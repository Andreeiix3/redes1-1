/***************************************************************************
 practica1.h

 Compila: make
 Autores: Emilio Cuesta y Pablo Alejo Polania
 2017 EPS-UAM
***************************************************************************/

#ifndef PRACTICA1_H
#define PRACTICA1_H

/* Macros */
#define OK 0
#define ERROR 1

#define ETH_FRAME_MAX 2048  // Tamanio maximo trama ethernet
#define SECONDS_PER_DAY 86400;

#endif /* PRACTICA1_H */